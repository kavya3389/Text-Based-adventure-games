simple\_game module
===================

.. automodule:: simple_game
   :members:
   :undoc-members:
   :show-inheritance:
