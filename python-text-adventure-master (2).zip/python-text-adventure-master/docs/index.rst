Documentation
=============

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules.rst
   simple_game.rst
   ship_game.rst
   engine.rst

* :ref:`genindex`
