'Dave Briccetti’s Python Text Adventure Game Engine'
